CREATE TABLE users(
       userId int PRIMARY KEY,
       userName varchar(50)
);

CREATE TABLE answer(
       answerId int PRIMARY KEY,
       answerContent varchar(100)
);

CREATE TABLE question(
       questionId int PRIMARY KEY,
       questionContent varchar(100)
);

CREATE TABLE poll(
       pollId int PRIMARY KEY,
       pollTitle varchar(50),
       pollDpt varchar(50),
       userId int FOREIGN KEY REFERENCES users(userId)
);

CREATE TABLE vote(
       voteId int PRIMARY KEY,
       pollId int FOREIGN KEY REFERENCES poll(pollId),
       questionId int FOREIGN KEY REFERENCES question(questionId),
       answerId int FOREIGN KEY REFERENCES answer(answerId)
);
